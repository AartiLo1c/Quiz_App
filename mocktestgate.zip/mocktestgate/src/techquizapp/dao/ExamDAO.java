/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techquizapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.TreeSet;
import techquizapp.dbutil.DBConnection;
import techquizapp.pojo.ExamPojo;

/**
 *
 * @author rits
 */
public class ExamDAO {
    public static String getExamId()throws SQLException
    {
    String qry="Select count(*) as totalrows from Exam";
    int rowCount=0;
    Connection conn=DBConnection.getConnection();
    Statement st=conn.createStatement();
    ResultSet rs=st.executeQuery(qry);
    if(rs.next())
    rowCount=rs.getInt(1);
    String newId="EX-"+(rowCount+1);
    return newId;
}
    public static boolean addExam(ExamPojo newExam)throws SQLException{
        String qry="insert into Exam values(?,?,?)";
        Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement(qry);
        ps.setString(1,newExam.getExamId());
         ps.setString(2,newExam.getLanguage());
          ps.setInt(3,newExam.getTotalQuestions());
          int ans=ps.executeUpdate();
          return ans==1;
        
    }
     public static TreeSet<String> getAllExamId() throws  SQLException
    {
      Connection conn=DBConnection.getConnection();
     Statement st=conn.createStatement();
     ResultSet rs=st.executeQuery("Select examid from questions");
     TreeSet <String>allexamid = new TreeSet< >();
     while(rs.next())
     {
         String ename=rs.getString("examid");
         allexamid.add(ename);
     }
     return allexamid;
    }
      public static TreeSet<String> getAllExamLanguage() throws  SQLException
    {
      Connection conn=DBConnection.getConnection();
     Statement st=conn.createStatement();
     ResultSet rs=st.executeQuery("Select language from exam");
     TreeSet <String>alllanguage = new TreeSet< >();
     while(rs.next())
     {
         String lang=rs.getString("language");
         alllanguage.add(lang);
     }
     return alllanguage;
    }
      public static ExamPojo getAllEditableQuestions(String examid,String lang) throws  SQLException
    {
      Connection conn=DBConnection.getConnection();
     Statement st=conn.createStatement();
     PreparedStatement ps=conn.prepareStatement("Select * from exam where examid=? and language=?");
     ps.setString(1, examid);
     ps.setString(2, lang);
     ResultSet rs=ps.executeQuery();
     ExamPojo e=null;
     if(rs.next())
     {
         e=new ExamPojo();
         e.setExamId(rs.getString(1));
         e.setLanguage(rs.getString(2));
         e.setTotalQuestions(rs.getInt(3));
     
     }
     return e;
    }
      public static boolean isPaperSet(String subject)throws SQLException{
       String qry="Select examid from Exam where language=? ";       
           Connection conn=DBConnection.getConnection();
           PreparedStatement ps=conn.prepareStatement(qry);
           ps.setString(1,subject);
           ResultSet rs=ps.executeQuery();
           return rs.next();
      }
      public static ArrayList<String> getExamIdBySubject(String userid,String subject)throws SQLException{
       String qry="Select examid from Exam where language=? minus Select examid from performance where userid=?";
       //the above statement will bring arraylist of examid, for which student has not appeared for test//
       ArrayList<String> examList=new ArrayList<>();
       Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement(qry);
        ps.setString(1,subject);
        ps.setString(2,userid);
        ResultSet rs=ps.executeQuery();
       while(rs.next()){
               examList.add(rs.getString(1));
           }
         return examList;        
      }
      public static int getQuestionCountByExam(String examId)throws SQLException{
        String qry="select total_question from Exam where examid=?";
        Connection conn=DBConnection.getConnection();
          PreparedStatement ps=conn.prepareStatement(qry);
          ps.setString(1,examId);
          ResultSet rs=ps.executeQuery();
	    rs.next();
          int rowCount=rs.getInt(1);
          return rowCount;
        }

}