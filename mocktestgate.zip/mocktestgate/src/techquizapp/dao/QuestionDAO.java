/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techquizapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import techquizapp.dbutil.DBConnection;
import techquizapp.pojo.ExamPojo;
import techquizapp.pojo.QuestionPojo;
import techquizapp.pojo.QuestionStore;

/**
 *
 * @author rits
 */
public class QuestionDAO {
    public static void addQuestions(QuestionStore qstore)throws SQLException{
        ArrayList<QuestionPojo> questionList=qstore.getAllQuestions();
         Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("Insert into questions values(?,?,?,?,?,?,?,?,?)");
       for(QuestionPojo obj:questionList){
        ps.setString(1, obj.getExamId());
        ps.setInt(2, obj.getQno());
        ps.setString(3, obj.getQuestion());
        ps.setString(4, obj.getAnswer1());
        ps.setString(5, obj.getAnswer2());
        ps.setString(6, obj.getAnswer3());
        ps.setString(7, obj.getAnswer4());
        ps.setString(8, obj.getCorrectAnswer());
        ps.setString(9, obj.getLanguage());
        ps.executeUpdate();
       }
        
       }
    public static ArrayList<QuestionPojo> getAllQuestions(String examid,String lang) throws  SQLException
    {
      Connection conn=DBConnection.getConnection();
     PreparedStatement ps=conn.prepareStatement("Select * from questions where examid=? and language=?");
     ps.setString(1, examid);
     ps.setString(2, lang);
     ResultSet rs=ps.executeQuery();
     ArrayList<QuestionPojo> qp=new ArrayList<>();
     while(rs.next())
     {
         QuestionPojo e=null;
         e=new QuestionPojo();
         e.setExamId(rs.getString(1));
         e.setQno(rs.getInt(2));
         e.setLanguage(rs.getString(9));
         e.setQuestion(rs.getString(3));
         e.setCorrectAnswer(rs.getString(8));
        e.setAnswer1(rs.getString(4));
        e.setAnswer2(rs.getString(5));
        e.setAnswer3(rs.getString(6));
        e.setAnswer4(rs.getString(7));
         qp.add(e);
     }
     return qp;
        
    }
    public static ArrayList <QuestionPojo> getQuestionsByExamId(String examId)throws SQLException
             {
      Connection conn=DBConnection.getConnection();
     PreparedStatement ps=conn.prepareStatement("Select * from questions where examid=?");
     ps.setString(1, examId);
     ResultSet rs=ps.executeQuery();
     ArrayList<QuestionPojo> qp=new ArrayList<>();
     while(rs.next())
     {
         QuestionPojo e=null;
         e=new QuestionPojo();
         e.setExamId(rs.getString(1));
         e.setQno(rs.getInt(2));
         e.setLanguage(rs.getString(9));
         e.setQuestion(rs.getString(3));
         e.setCorrectAnswer(rs.getString(8));
        e.setAnswer1(rs.getString(4));
        e.setAnswer2(rs.getString(5));
        e.setAnswer3(rs.getString(6));
        e.setAnswer4(rs.getString(7));
         qp.add(e);
     }
     return qp;
        
    }
       public static void updateAllQuestions(QuestionStore qstore)throws SQLException{
        ArrayList<QuestionPojo> questionList=qstore.getAllQuestions();
           System.out.println(questionList);
         Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("UPDATE questions SET examid=?,qno=?,question=?,answer1=?,answer2=?,answer3=?,answer4=?,correct_answer=?,language=? WHERE examid=? and qno=?");
           System.out.println(qstore);
        for(QuestionPojo obj1:questionList){
        ps.setString(1, obj1.getExamId());
        ps.setInt(2, obj1.getQno());
        ps.setString(3, obj1.getQuestion());
        ps.setString(4, obj1.getAnswer1());
        ps.setString(5, obj1.getAnswer2());
        ps.setString(6, obj1.getAnswer3());
        ps.setString(7, obj1.getAnswer4());
        ps.setString(8, obj1.getCorrectAnswer());
        ps.setString(9, obj1.getLanguage());
        String qn=obj1.getExamId();
        int n=obj1.getQno();
        ps.setString(10, qn);
        ps.setInt(11,n);
        ps.executeUpdate();
       }
        
       }
    
    
}
