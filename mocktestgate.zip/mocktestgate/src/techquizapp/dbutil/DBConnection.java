/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techquizapp.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author rits
 */
public class DBConnection {
     private static Connection conn;
static
{
     try
        { 
            Class.forName("oracle.jdbc.driver.OracleDriver");
//            conn=DriverManager.getConnection("jdbc:oracle:thin:@//ritesh:1521/xe","system","ramanand");
              conn=DriverManager.getConnection("jdbc:oracle:thin:@//DESKTOP-05DA8E6:1521/xe","onlineexam","student");
              JOptionPane.showMessageDialog(null, "connected Sucessfully");
  
        }
        catch(Exception e)
                {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null,"can not connect to database");
                }
}
     public static Connection getConnection()
     {
         return conn;
     }
     public static void closeConnection()
     {
         try
         {
             conn.close();
             JOptionPane.showMessageDialog(null,"cannection closed to database sucessfully");
         }
          catch(Exception e)
                {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null,"not able  to disconnect database");
                }
     }
    
}
