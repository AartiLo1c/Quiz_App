/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techquizapp.pojo;

import java.util.Objects;

/**
 *
 * @author rits
 */
public class UserPojo {
    private String userId;
    private String password;
    private String userType;
    private String emailId;
    private String adharNo;
    public UserPojo()
    {
        
    }

    public UserPojo(String userId, String password, String userType, String emailId, String adharNo) {
        this.userId = userId;
        this.password = password;
        this.userType = userType;
        this.emailId = emailId;
        this.adharNo = adharNo;
    }

    public String getUserId() {
        return userId;
    }

    @Override
    public String toString() {
        return "UserPojo{" + "userId=" + userId + ", password=" + password + ", userType=" + userType + ", emailId=" + emailId + ", adharNo=" + adharNo + '}';
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getAdharNo() {
        return adharNo;
    }

    public void setAdharNo(String adharNo) {
        this.adharNo = adharNo;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final UserPojo other = (UserPojo) obj;
        if (!Objects.equals(this.userId, other.userId)) {
            return false;
        }
        if (!Objects.equals(this.password, other.password)) {
            return false;
        }
        if (!Objects.equals(this.userType, other.userType)) {
            return false;
        }
        if (!Objects.equals(this.emailId, other.emailId)) {
            return false;
        }
        if (!Objects.equals(this.adharNo, other.adharNo)) {
            return false;
        }
        return true;
    }
    
}
