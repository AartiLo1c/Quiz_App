/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package techquizapp.pojo;

import java.util.Objects;

/**
 *
 * @author rits
 */
public class ExamPojo {
    private String examid;
    private String language;
    private int totalquestions;
    
    public ExamPojo(){
        
    }

    public ExamPojo(String examid, String language, int totalquestions) {
        this.examid = examid;
        this.language = language;
        this.totalquestions = totalquestions;
    }

    public String getExamId() {
        return examid;
    }

    public void setExamId(String examid) {
        this.examid = examid;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public int getTotalQuestions() {
        return totalquestions;
    }

    public void setTotalQuestions(int totalquestions) {
        this.totalquestions = totalquestions;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 79 * hash + Objects.hashCode(this.examid);
        hash = 79 * hash + Objects.hashCode(this.language);
        hash = 79 * hash + this.totalquestions;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ExamPojo other = (ExamPojo) obj;
        if (this.totalquestions != other.totalquestions) {
            return false;
        }
        if (!Objects.equals(this.examid, other.examid)) {
            return false;
        }
        if (!Objects.equals(this.language, other.language)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ExamPojo{" + "examid=" + examid + ", language=" + language + ", totalquestions=" + totalquestions + '}';
    }
    
}
